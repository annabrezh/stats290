library(testthat)
library(annna)

test_check("annna")
